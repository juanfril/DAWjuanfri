﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PersonajeMovil
{
    class Program
    {
        static void Main(string[] args)
        {
            Juego j = new Juego();
            j.Lanzar();
        }
    }
}
