﻿using GestionMantenimiento.Tecnicos;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GestionMantenimiento.GestionPreventivos
{
    class Preventivo
    {
        string usuario;
        string tecnico;
        string nombreElemento;
        DateTime realizado;

        public Preventivo(string usuario, string tecnico, string nombreElemento)
        {
            this.usuario = usuario;
            this.tecnico = tecnico;
            this.nombreElemento = nombreElemento;
            realizado = DateTime.Now;
        }

        public override string ToString()
        {
            return usuario + ";" + tecnico + ";" + nombreElemento +
                ";" + realizado.ToString("d");
        }
    }
}
