﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace GestionMantenimiento
{
    class MaquinaGeneral
    {
        //public static int contador;
        //public int Identificador { get; private set; }
        public string Nombre { get; set; }
        public string Ubicacion { get; set; }
        public string TipoInstalacion { get; set; }

        public MaquinaGeneral(string nombre, string ubicacion,
            string tipoInstalacion)
        {
            //Identificador = Interlocked.Increment(ref contador);
            Nombre = nombre;
            Ubicacion = ubicacion;
            TipoInstalacion = tipoInstalacion;
        }
        
        public override string ToString()
        {
            return Nombre + ";" + Ubicacion + ";" + TipoInstalacion;
        }
    }
}
