﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GestionMantenimiento
{
    class Climatizacion : MaquinaGeneral
    {
        public string TipoRefrigerante { get; set; }

        public Climatizacion(string nombre, string ubicacion,
            string tipoInstalacion, string tipoRefrigerante)
            : base(nombre, ubicacion, tipoInstalacion)
        {
            TipoRefrigerante = tipoRefrigerante;
        }
        public override string ToString()
        {
            return base.ToString() + ";" + TipoRefrigerante;
        }
    }
}
