﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GestionMantenimiento
{
    class Electricidad : MaquinaGeneral
    {
        public string TipoCableado { get; set; }

        public Electricidad(string nombre, string ubicacion,
            string tipoInstalacion, string tipoCableado)
            : base(nombre, ubicacion, tipoInstalacion)
        {
            TipoCableado = tipoCableado;
        }
        public override string ToString()
        {
            return base.ToString() + ";" + TipoCableado;
        }
    }
}
