﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GestionMantenimiento.ElementosInstalacion
{
    public partial class anyadirElemento : Form
    {
        public anyadirElemento()
        {
            InitializeComponent();
        }

        private void btnAnyadir_Click(object sender, EventArgs e)
        {
            Close();
        }

        public string GetNombre()
        {
            return tbNombre.Text;
        }
        public string GetUbicacion()
        {
            return tbUbicacion.Text;
        }
        public string GetOficio()
        {
            return cbOficio.SelectedItem.ToString();
        }
        public string GetOpcion()
        {
            return tbOpcion.Text;
        }

        private void cbOficio_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (cbOficio.SelectedItem.ToString())
            {
                case "frigorista":
                    lbOpcion.Text = "Tipo Gas";
                    break;
                case "electricista":
                    lbOpcion.Text = "Instalación";
                    break;
                case "fontanero":
                    lbOpcion.Text = "Tipo tubería";
                    break;
            }
        }
    }
}
