'use strict';

let diasSemana = [
    'Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado', 'Domingo'
];

for (let dia in diasSemana)
    console.log(diasSemana[dia]);

for (let dia of diasSemana)
    console.log(dia);    