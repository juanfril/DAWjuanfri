#!/bin/bash

read -n 10 -p "Dime tu nombre:" nombre apellido

echo "Tu nombre es $nombre"
echo "Tu apellido es $apellido"