#!/bin/bash

#lineas=($(cat personas.txt))

declare -i linea=1
declare -i num

set -f; OLDIFS="$IFS"; IFS=";"
while read -r nombre edad
do
	echo "${linea}) $nombre - $edad"
	let linea++
done < personas.txt
set +f; IFS="$OLDIFS"

echo "Persona a modificar"
read num

if (( $num < 1 || $num > $(cat personas.txt | wc -l) ))
then
	echo "Línea no válida"
	exit 1
fi

persona="$(cat personas.txt | sed -n "${num}p")"
nombre="$(echo $persona | cut -d ';' -f1)"
edad="$(echo $persona | cut -d ';' -f2)"

read -p "Nombre: $nombre. Nuevo nombre: " nuevoNombre
read -p "Edad: $edad. Nueva edad: " nuevaEdad

(($num > 1)) && sed -n "1,$((num-1))p" personas.txt > temporal.txt
echo "$nuevoNombre;$nuevaEdad" >> temporal.txt
sed -n "$((num+1)),\$p" personas.txt >> temporal.txt

mv temporal.txt personas.txt

echo "Guardado con Éxito!"


