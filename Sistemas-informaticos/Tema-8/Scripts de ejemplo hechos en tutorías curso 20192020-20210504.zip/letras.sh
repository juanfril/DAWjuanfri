#!/bin/bash

palabra="carcasa"
letra="a"
declare -i veces=0

for ((i = 0; i < ${#palabra}; i++))
do
	letraPalabra="${palabra:$i:1}"
	if [[ "$letra" == "$letraPalabra" ]]
	then
		let veces++
	fi
done

echo "La letra $letra aparece $veces veces en $palabra"

