package houses.data;

/**
 * This class represents a small apartment, which is a subtype of House
 */

public class SmallApartment extends House{

    public SmallApartment(Door door) {
        super(50, door);
    }
}
