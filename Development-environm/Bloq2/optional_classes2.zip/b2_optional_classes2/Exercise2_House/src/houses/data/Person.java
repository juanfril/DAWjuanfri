package houses.data;

/**
 * This class represents a person with a house
 */

public class Person {

    private String name;
    private House house;

    public Person(String name, House house) {
        this.name = name;
        this.house = house;
    }

    @Override
    public String toString() {
        return "Name: " + name + "\n" + house + "\n" + house.getDoor();
    }
}
