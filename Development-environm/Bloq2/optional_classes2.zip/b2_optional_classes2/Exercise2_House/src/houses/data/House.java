package houses.data;

/**
 * This class represents a house with its own door
 */

public class House {

    protected int area;
    protected Door door;

    public House(int area, Door door) {
        this.area = area;
        this.door = door;
    }

    public int getArea() {
        return area;
    }

    public void setArea(int area) {
        this.area = area;
    }

    public Door getDoor() {
        return door;
    }

    @Override
    public String toString() {
        return "I am a house, and my area is " + area + "m2";
    }
}
