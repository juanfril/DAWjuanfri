package houses.main;

import houses.data.Door;
import houses.data.Person;
import houses.data.SmallApartment;

/**
 * Main class to test the program
 */

public class Main {

    public static void main(String[] args) {

        SmallApartment a = new SmallApartment(new Door("brown"));
        Person p = new Person("Pepe", a);
        System.out.println(p);
    }
}
