package GeometricalFigures.data;

/**
 * Interface to draw elements
 */

public interface IDrawable {
    public void draw();
}
