package GeometricalFigures.data;

/**
 * Subtype of geometrical figure to represent a square
 */

public class Square extends GeometricalFigure implements IMeasurable, IDrawable {

    public Square(int x1, int y1, int x2, int y2) {
        super(x1, y1, x2, y2);
    }

    public Square() { }

    @Override
    public void show() {
        System.out.println("Square: " + getSize());
    }

    @Override
    public float getSize() {
        return (x2 - x1) * (y2 - y1);
    }

    @Override
    public void draw() {
        System.out.println("Drawing a square...");
    }
}
