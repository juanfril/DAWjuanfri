package GeometricalFigures.data;

/**
 * Interface to calculate the size of elements
 */

public interface IMeasurable {
    public float getSize();
}
