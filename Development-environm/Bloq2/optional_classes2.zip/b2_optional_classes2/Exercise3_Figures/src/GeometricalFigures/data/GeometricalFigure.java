package GeometricalFigures.data;

/**
 * This is the parent, abstract class for every geometrical figure
 */

public abstract class GeometricalFigure {

    protected float x1, y1, x2, y2;

    public GeometricalFigure(int x1, int y1, int x2, int y2) {
        this.x1 = x1;
        this.y1 = y1;
        this.x2 = x2;
        this.y2 = y2;
    }

    public GeometricalFigure() { this (0, 0, 10, 10); }

    public abstract void show();
}
