package GeometricalFigures.main;

/**
 * Main class to test the program
 */

import GeometricalFigures.data.Square;
import GeometricalFigures.data.Triangle;

public class Main {

    public static void main(String[] args) {

        Square square = new Square();
        Triangle triangle = new Triangle(0, 0, 4, 4);

        square.draw();
        square.getSize();
        square.show();

        triangle.draw();
        triangle.getSize();
        triangle.show();
    }
}
