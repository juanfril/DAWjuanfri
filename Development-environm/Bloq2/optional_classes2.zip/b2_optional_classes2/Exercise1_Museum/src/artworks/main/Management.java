package artworks.main;

import artworks.data.*;

import java.util.Scanner;

/**
 * Additional class to manage artworks and authors
 */

public class Management {

    private static final int MAX_ELEMENTS = 10;

    private Author[] authors;
    private Artwork[] artworks;
    private int numAuthors;
    private int numArtworks;

    public Management() {

        authors = new Author[MAX_ELEMENTS];
        artworks = new Artwork[MAX_ELEMENTS];
        numAuthors = numArtworks = 0;
    }

    public void insertArtwork(Scanner sc) {

        String owner, name, material;
        int year, artworkType;
        int authorPosition = 0;

        if (numArtworks < MAX_ELEMENTS && authors.length > 0) {

            System.out.println("1. Sculpture / 2. Painting:");
            artworkType = sc.nextInt();
            sc.nextLine();

            if (artworkType == 1 || artworkType == 2) {

                System.out.println("Insert name of the artwork:");
                name = sc.nextLine();
                System.out.println("Insert the owner of the artwork:");
                owner = sc.nextLine();
                System.out.println("Insert year of the artwork:");
                year = sc.nextInt();
                sc.nextLine();

                showAuthors();
                System.out.println("Choose author position:");
                authorPosition = sc.nextInt() - 1;
                sc.nextLine();

                if (artworkType == 1) {
                    System.out.println("Insert material of the sculpture:");
                    material = sc.nextLine();
                    artworks[numArtworks++] = new Sculpture(authors[authorPosition], owner,
                            name, year, material);
                } else {
                    artworks[numArtworks++] = new Painting(authors[authorPosition], owner,
                            name, year);
                }
            } else {
                System.err.println("Incorrect artwork type");
            }
        } else {
            System.err.println("Not enough space, or no authors defined");
        }
    }

    public void insertAuthor(Scanner sc) {

        if (numAuthors < MAX_ELEMENTS) {
            System.out.println("Name:");
            String authorName = sc.nextLine();
            authors[numAuthors++] = new Author(authorName);
        }
        else
            System.out.println("Not enough space");
    }

    public void showAuthors() {

        if (numAuthors > 0) {
            for (int i = 0; i < numAuthors; i++)
                System.out.println((i+1) + ". " + authors[i]);
        }
        else
            System.out.println("No authors stored");
    }

    public void showArtworks() {

        if (numArtworks > 0) {
            for (int i = 0; i < numArtworks; i++)
                System.out.println(artworks[i]);
        }
        else
            System.out.println("No artworks stored");
    }
}
