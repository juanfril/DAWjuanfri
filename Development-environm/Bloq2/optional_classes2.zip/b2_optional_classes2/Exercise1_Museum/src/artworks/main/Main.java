package artworks.main;

import java.util.Scanner;

/**
 * Main class to manage authors and artworks
 */

public class Main {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        Management mgm = new Management();
        int option;

        do {
            System.out.println("1. Insert artwork");
            System.out.println("2. Insert author");
            System.out.println("3. Show artworks");
            System.out.println("4. Show authors");
            System.out.println("0. Exit");

            option = sc.nextInt();
            sc.nextLine();

            switch (option) {
                case 1: mgm.insertArtwork(sc); break;
                case 2: mgm.insertAuthor(sc); break;
                case 3: mgm.showArtworks(); break;
                case 4: mgm.showAuthors(); break;
            }

        } while (option != 0);
    }
}
