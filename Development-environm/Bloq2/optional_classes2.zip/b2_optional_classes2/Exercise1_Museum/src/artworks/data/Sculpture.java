package artworks.data;

/**
 * Class to define a subtype of artwork: sculptures
 */

public class Sculpture extends Artwork {
    private String material;


    public Sculpture(Author author, String owner, String name, int year, String material) {
        super(author, owner, name, year);
        this.material = material;
    }

    public String getMaterial() {
        return material;
    }

    public void setMaterial(String material) {
        this.material = material;
    }

    @Override
    public String toString() {
        return "Sculpture: " + super.toString() + " (" + material + ")";
    }
}
