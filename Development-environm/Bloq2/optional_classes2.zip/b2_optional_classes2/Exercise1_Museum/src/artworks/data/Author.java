package artworks.data;

/**
 * Class to store the information about the artworks authors
 */

public class Author {

    private String name;

    public Author(String author) {
        this.name = author;
    }

    public String getAuthor() {
        return name;
    }

    public void setAuthor(String author) {
        this.name = author;
    }

    @Override
    public String toString() {
        return name;
    }
}
