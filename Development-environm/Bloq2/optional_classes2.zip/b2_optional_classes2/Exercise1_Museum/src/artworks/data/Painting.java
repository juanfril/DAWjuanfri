package artworks.data;

/**
 * Class to define a subtype of artwork: paintings
 */

public class Painting extends Artwork {

    public Painting(Author author, String owner, String name, int year) {
        super(author, owner, name, year);
    }

    @Override
    public String toString() {
        return "Painting: " + super.toString();
    }
}
