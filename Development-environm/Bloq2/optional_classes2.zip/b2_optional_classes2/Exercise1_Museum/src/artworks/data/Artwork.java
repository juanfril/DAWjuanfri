package artworks.data;

/**
 * This abstract class will be the parent class of every artwork
 */

public class Artwork {

    protected Author author;
    protected String owner;
    protected String name;
    protected int year;

    public Artwork(Author author, String owner, String name, int year) {
        this.author = author;
        this.owner = owner;
        this.name = name;
        this.year = year;
    }

    public Author getAuthor() {
        return author;
    }

    public void setAuthor(Author author) {
        this.author = author;
    }

    public String getOwner() {
        return owner;
    }

    public void setOwner(String owner) {
        this.owner = owner;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    @Override
    public String toString() {
        return name + "(" + author + "), " + owner + ", " + year;
    }
}
