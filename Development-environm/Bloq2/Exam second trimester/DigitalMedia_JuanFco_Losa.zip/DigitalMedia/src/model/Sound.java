package model;

public class Sound extends DigitalFile{
    boolean stereo;
    int kbps, length;

    public Sound(String nameAuthor, String countryAuthor, int KB, String format,
                 int year, boolean stereo, int kbps, int length) {
        super(nameAuthor, countryAuthor, KB, format, year);
        this.stereo = stereo;
        this.kbps = kbps;
        this.length = length;
    }

    public boolean isStereo() {
        return stereo;
    }

    public void setStereo(boolean stereo) {
        this.stereo = stereo;
    }

    public int getKbps() {
        return kbps;
    }

    public void setKbps(int kbps) {
        this.kbps = kbps;
    }

    public int getLength() {
        return length;
    }

    public void setLength(int length) {
        this.length = length;
    }

    @Override
    public String toString(){
        return super.toString() + (stereo ? ". Stereo ." : ". Mono .") + kbps +
                "kbps " + (length == 1 ? length + " second." : length + " seconds.");
    }
}
