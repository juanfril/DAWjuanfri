package model;

public class Author {
    String nameAuthor, countryAuthor;

    public Author(String nameAuthor, String countryAuthor) {
        this.nameAuthor = nameAuthor;
        this.countryAuthor = countryAuthor;
    }

    public String getNameAuthor() {
        return nameAuthor;
    }

    public void setNameAuthor(String nameAuthor) {
        this.nameAuthor = nameAuthor;
    }

    public String getCountryAuthor() {
        return countryAuthor;
    }

    public void setCountryAuthor(String countryAuthor) {
        this.countryAuthor = countryAuthor;
    }

    @Override
    public String toString(){
        return "Author: " + nameAuthor + " (" + countryAuthor + ")";
    }
}
