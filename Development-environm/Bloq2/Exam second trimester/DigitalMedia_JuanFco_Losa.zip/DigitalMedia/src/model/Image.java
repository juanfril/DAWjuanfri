package model;

public class Image extends DigitalFile implements Sizable{
    int width, height;
    String compression;

    public Image(String nameAuthor, String countryAuthor, int KB, String format,
                 int year, int width, int height, String compression) {
        super(nameAuthor, countryAuthor, KB, format, year);
        this.width = width;
        this.height = height;
        this.compression = compression;
    }

    public int getWidth() {
        return width;
    }

    public void setWidth(int width) {
        this.width = width;
    }

    public int getHeight() {
        return height;
    }

    public void setHeight(int height) {
        this.height = height;
    }

    public String getCompression() {
        return compression;
    }

    public void setCompression(String compression) {
        this.compression = compression;
    }

    @Override
    public int getSize() {
        return width * height;
    }

    @Override
    public String toString(){
        return super.toString() + ". Width: " + width + ". Height: " + height +
                ". Compression: " + compression;
    }
}
