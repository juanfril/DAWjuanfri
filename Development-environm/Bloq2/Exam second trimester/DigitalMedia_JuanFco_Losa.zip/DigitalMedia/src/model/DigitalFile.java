package model;

public abstract class DigitalFile extends Author{
    protected int KB;
    protected String format;
    protected int year;

    public DigitalFile(String nameAuthor, String countryAuthor, int KB,
                       String format, int year) {
        super(nameAuthor, countryAuthor);
        this.KB = KB;
        this.format = format;
        this.year = year;
    }

    public int getKB() {
        return KB;
    }

    public void setKB(int KB) {
        this.KB = KB;
    }

    public String getFormat() {
        return format;
    }

    public void setFormat(String format) {
        this.format = format;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    @Override
    public String toString(){
        return super.toString() + ". This file have format: " + format +
                " " + KB + "KB. On the year " + year;
    }
}
