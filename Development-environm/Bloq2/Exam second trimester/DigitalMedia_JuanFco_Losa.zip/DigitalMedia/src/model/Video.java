package model;

public class Video extends Image{
    String codec;
    int length;

    public Video(String nameAuthor, String countryAuthor, int KB, String format, int year, int width,
                 int height, String compression, String codec, int length) {
        super(nameAuthor, countryAuthor, KB, format, year, width, height, compression);
        this.codec = codec;
        this.length = length;
    }

    public String getCodec() {
        return codec;
    }

    public void setCodec(String codec) {
        this.codec = codec;
    }

    public int getLength() {
        return length;
    }

    public void setLength(int length) {
        this.length = length;
    }

    @Override
    public String toString(){
        return super.toString() + ". Codec: " + codec + ". " +
                (length == 1 ? length +  " second." : length + " seconds.");
    }
}
