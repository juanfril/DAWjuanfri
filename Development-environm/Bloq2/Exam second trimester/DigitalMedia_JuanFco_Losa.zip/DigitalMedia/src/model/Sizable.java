package model;

public interface Sizable {
    public int getSize();
}
