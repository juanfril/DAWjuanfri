/*
* Juan Fco. Losa Márquez
* Exam second trimester
* */

package main;

import model.*;

import java.util.Arrays;
import java.util.Comparator;
import java.util.Scanner;

public class Main {
    private static void showMenu()
    {
        System.out.println("\nDigital Files\n");
        System.out.println("1. Show all elements");
        System.out.println("2. Show all elements ordered by KB in ascending order");
        System.out.println("3. Show only one kind of element");
        System.out.println("4. Normalize author names");
        System.out.println("5. Show all elements ordered by:");
        System.out.println("0. Exit");
        System.out.print("\nChoose an option: ");
    }
    //don't work, it's the only code I repeat :(
    /*private void showElements(DigitalFile elements){
        for (DigitalFile e : elements ) {
            System.out.println(e);
        }
    }*/
    private static final int MAX_ELEMENTS = 9;
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int option;
        DigitalFile[] elements = new DigitalFile[MAX_ELEMENTS];

        elements[0] = new Image("Jhon Andrews", "EEUU", 2,
                "JPG", 1990, 150, 300, "zip");
        elements[1] = new Image("Geo", "France", 3,
                "PNG", 2005, 750, 1200, "7z");
        elements[2] = new Image("Diego", "Spain", 4,
                "JPG", 2002, 500, 800, "RAR");
        elements[3] = new Sound("James", "UK", 1,
                "WAV", 2008, true, 900, 6);
        elements[4] = new Sound("Hans", "Holland", 1,
                "MPEG-4", 2005, false, 600, 1);
        elements[5] = new Sound("James", "UK", 1,
                "FLAC", 2018, true, 500, 8);
        elements[6] = new Video("Adam", "Monaco", 500,
                "mp4", 2015, 1024, 1500, "FLV",
                " K-Lite", 4500);
        elements[7] = new Video("Elder", "New Zealand", 500,
                "Divs", 2015, 1024, 1500, "FLV",
                " K-Lite", 5000);
        elements[8] = new Video("Aaron", "Poland", 500,
                "h264", 2015, 1024, 1500, "FLV",
                " K-Lite", 3000);

        do
        {
            showMenu();
            option = sc.nextInt();

            switch(option)
            {
                case 1:
                    for (Object e : elements ) {
                        System.out.println(e);
                    }
                    break;
                case 2:
                    Arrays.sort(elements, new Comparator<DigitalFile>()
                    {
                        @Override
                        public int compare(DigitalFile o1, DigitalFile o2) {
                            return Integer.compare(o1.getKB(), o2.getKB());
                        }
                    });
                    for (Object e : elements ) {
                        System.out.println(e);
                    }
                    break;
                case 3:
                    System.out.println("\nShow for: \n");
                    System.out.println("1. Image");
                    System.out.println("2. Sound");
                    System.out.println("3. Video");
                    System.out.print("\nChoose an option: ");
                    option = sc.nextInt();

                    switch (option){
                        case 1:
                            for (Object e : elements ) {
                                if(e instanceof Image)
                                    System.out.println(e);
                            }
                            break;
                        case 2:
                            for (Object e : elements ) {
                                if(e instanceof Sound)
                                    System.out.println(e);
                            }
                            break;
                        case 3:
                            for (Object e : elements ) {
                                if(e instanceof Video)
                                    System.out.println(e);
                            }
                            break;
                        default:
                            System.out.println("Sorry I don't understand. Try again");
                            break;
                    }
                    break;
                case 4:

                    break;
                case 5:
                    System.out.println("\nShow for: \n");
                    System.out.println("1. Format");
                    System.out.println("2. Year of creation");
                    System.out.print("\nChoose an option: ");
                    option = sc.nextInt();

                    switch (option){
                        case 1:
                            Arrays.sort(elements, new Comparator<DigitalFile>()
                            {
                                @Override
                                public int compare(DigitalFile o1, DigitalFile o2) {
                                    return CharSequence.compare(o1.getFormat(), o2.getFormat());
                                }
                            });
                            for (Object e : elements ) {
                                System.out.println(e);
                            }
                            break;
                        case 2:
                            Arrays.sort(elements, new Comparator<DigitalFile>()
                            {
                                @Override
                                public int compare(DigitalFile o1, DigitalFile o2) {
                                    return Integer.compare(o1.getYear(), o2.getYear());
                                }
                            });
                            for (Object e : elements ) {
                                System.out.println(e);
                            }
                            break;
                        default:
                            System.out.println("Sorry I don't understand. Try again");
                            break;
                    }
                    break;
            }
        } while (option != 0);
    }
}
