package house.main;

public class SmallApartment extends House{

    public SmallApartment(){
        setArea(50);
    }
}
