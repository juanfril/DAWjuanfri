package house.main;

public class Main {

    public static void main(String[] args) {
	    Person person = new Person("Paco");

	    System.out.println(person);
    }
}
