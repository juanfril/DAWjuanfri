package Measure.main;

public interface Measurable {
    public int getSize();
}
