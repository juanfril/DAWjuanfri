package Measure.main;

public interface Drawable {
    public void draw();
}
