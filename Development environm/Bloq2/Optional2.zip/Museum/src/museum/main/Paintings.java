package museum.main;

public class Paintings extends Artworks{

}
