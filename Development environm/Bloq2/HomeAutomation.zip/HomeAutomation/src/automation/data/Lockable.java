package automation.data;

public interface Lockable {
    public void on();

    public void off();
}
