package automation.data;

public class Oven extends Heating implements AutomationElement{
    public Oven(String name) {
        super(name);
    }
}
