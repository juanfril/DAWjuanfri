package automation.data;

public class Oven extends Heating implements Temperature {
    public Oven(String name) {
        super(name);
    }
}
