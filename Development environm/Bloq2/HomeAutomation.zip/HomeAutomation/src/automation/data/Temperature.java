package automation.data;

public interface Temperature {
    public int getTemperature();

    public void setTemperature(int number);
}
