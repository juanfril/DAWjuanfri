package automation.data;

public class Awning extends Blind implements AutomationElement{

    public Awning(String name) {
        super(name);
    }
}
